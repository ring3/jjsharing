package util

import (
	"crypto/rand"
	"encoding/hex"
	"github.com/dgrijalva/jwt-go"
	"time"
)

const (
	keyLength = 32
)

type TokenUtil struct {
	encryptMethod jwt.SigningMethod
	encryptKey    []byte
	validTime     time.Duration
}

func NewUserTokenUtil() *TokenUtil {
	tu := TokenUtil{
		encryptMethod: jwt.SigningMethodHS256,
		encryptKey:    []byte(randomKey()),
		validTime:     24 * time.Hour,
	}
	return &tu
}

func randomKey() string {
	rnd := make([]byte, keyLength)
	_, err := rand.Read(rnd)
	if err != nil {
		panic(err)
	}
	hexVal := hex.EncodeToString(rnd)
	return hexVal
}

type UserClaims struct {
	UserID uint64
	jwt.StandardClaims
}

func (tknu *TokenUtil) CreateUserToken(userID uint64) (string, error) {
	expireAt := time.Now().Add(tknu.validTime)
	claims := UserClaims{
		UserID: userID,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: expireAt.Unix(),
		},
	}
	token := jwt.NewWithClaims(tknu.encryptMethod, &claims)
	tokenString, err := token.SignedString(tknu.encryptKey)
	if err == nil {
		return tokenString, nil
	}
	return "", err
}

func (tknu *TokenUtil) V(token string) (*UserClaims, error) {
	claims := UserClaims{}
	_, err := jwt.ParseWithClaims(token, &claims,
		func(token *jwt.Token) (interface{}, error) { // jwt.Keyfunc
			return tknu.encryptKey, nil
		})
	if err == nil {
		return &claims, nil
	}
	return nil, err
}
