package util

import (
	"time"
)

const (
	httpServerShutdownTimeout = 10 * time.Second
	grpcServerShutdownTimeout = 10 * time.Second
)
