package util

import (
	"context"
	"go.uber.org/zap"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	"net"
)

type IGrpcService interface {
	Register(*grpc.Server)
}

type GrpcServerConfig struct {
	Addr    string
	Timeout int
}

type GrpcServer struct {
	server  *grpc.Server
	config  *GrpcServerConfig
	Impl    IGrpcService
	ErrChan chan error
	Log     *zap.Logger
}

func NewGrpcServer(impl IGrpcService, cfg *GrpcServerConfig, logger *zap.Logger) *GrpcServer {

	var opts []grpc.ServerOption
	gs := GrpcServer{
		server:  grpc.NewServer(opts...),
		config:  cfg,
		ErrChan: make(chan error),
		Log:     logger,
	}

	impl.Register(gs.server)
	reflection.Register(gs.server)
	return &gs
}

func (gs *GrpcServer) Run() error {
	listen, err := net.Listen("tcp", gs.config.Addr)
	gs.Log.Info("grpc listening at tcp", zap.String("addr", gs.config.Addr))

	err = gs.server.Serve(listen)
	if err != nil {
		gs.Log.Info("grpcServer.Run()fail", zap.Error(err))
		return err
	}
	return nil
}

func (gs *GrpcServer) Shutdown() {
	gs.Log.Info("grpc server begin shutdown.")
	shutdownCh := make(chan int)
	go func() {
		gs.server.GracefulStop()
		close(shutdownCh)
	}()
	ctx, cancel := context.WithTimeout(context.Background(), grpcServerShutdownTimeout)
	defer cancel()
	select {
	case <-ctx.Done():
		gs.Log.Error("grpc server shutdown timeout")
		gs.server.Stop()
	case <-shutdownCh:
	}
	gs.Log.Info("grpc server end shutdown.")
}
