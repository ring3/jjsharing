package util

// server is part of component, if it fails, owner component should be notified.
// and in turn the node get notified by the failed component.

import (
	"context"
	"encoding/json"
	// "github.com/ring3/goserve/core"
	"go.uber.org/zap"
	"google.golang.org/protobuf/proto"
	"io/ioutil"
	"net"
	"net/http"
	"strings"
	"time"
)

type HttpError struct {
	err  error
	code int
}

func NewHttpError(e error, c int) *HttpError {
	herr := HttpError{
		err:  e,
		code: c,
	}
	return &herr
}

func (he *HttpError) StatusCode() int {
	return he.code
}

func (he *HttpError) Error() string {
	return he.err.Error()
}

// server
type HttpServerConfig struct {
	Addr         string
	ReadTimeout  int
	WriteTimeout int
	IdleTimeout  int
	// MaxReaderBytes //???
	CertFile string
	KeyFile  string
}

type HttpServer struct {
	server  *http.Server
	Mux     *http.ServeMux
	config  *HttpServerConfig
	ErrChan chan error
	Log     *zap.Logger
}

func NewHttpServer(cfg *HttpServerConfig, logger *zap.Logger) *HttpServer {
	mux := http.NewServeMux()

	// mux can be wrapped by other handlers, like gzip, prometheus, etc.
	// as we are intend to using protobuf as transport format, no need gzip here.
	hs := HttpServer{
		config: cfg,
		server: &http.Server{
			Addr:         cfg.Addr,
			ReadTimeout:  time.Second * time.Duration(cfg.ReadTimeout),
			WriteTimeout: time.Second * time.Duration(cfg.WriteTimeout),
			IdleTimeout:  time.Second * time.Duration(cfg.IdleTimeout),
			Handler:      mux,
		},
		Mux:     mux,
		ErrChan: make(chan error),
		Log:     logger,
	}

	return &hs
}

func (hs *HttpServer) Run() error {
	if hs.config.CertFile != "" && hs.config.KeyFile != "" {
		// tls
		err := hs.server.ListenAndServeTLS(hs.config.CertFile, hs.config.KeyFile)
		if err != nil {
			hs.Log.Info("httpServer.ListenAndServeTLS fail", zap.String("err", err.Error()))
			return err
		}
	} else {
		hs.Log.Info("httpServer.ListenAndServe() starting...", zap.String("addr", hs.config.Addr))
		err := hs.server.ListenAndServe()
		if err != nil {
			hs.Log.Info("httpServer.ListenAndServe fail", zap.String("err", err.Error()))
			return err
		}
	}
	return nil
}

func (hs *HttpServer) Shutdown() {
	ctx, cancel := context.WithTimeout(context.Background(), httpServerShutdownTimeout)
	err := hs.server.Shutdown(ctx)
	if err != nil {
		hs.Log.Warn("HttpServer.Shutdowndown() error", zap.Any("error", err))
	}
	cancel()
}

type HttpHandleFunc func(http.ResponseWriter, *http.Request) error

// ServeHTTP(w, r) error
func (hs *HttpServer) Handle(url string, f HttpHandleFunc) {
	if hs.Mux == nil {
		hs.Log.Error("httpServer.Handle(), hs.Mux is nil")
		return
	}

	handleFunc := http.HandlerFunc(
		func(w http.ResponseWriter, r *http.Request) {
			err := f(w, r)
			if err != nil {
				if herr, ok := err.(*HttpError); ok {
					http.Error(w, herr.Error(), herr.StatusCode())
				} else {
					http.Error(w, err.Error(), http.StatusInternalServerError)
				}
			}
		})
	hs.Mux.Handle(url, handleFunc)
}

func (hs *HttpServer) HandleFunc(url string, f http.HandlerFunc) {
	if hs.Mux == nil {
		hs.Log.Error("httpServer.HandleFunc(), hs.Mux is nil")
		return
	}
	hs.Mux.HandleFunc(url, f)
}

// misc
func ReadProtoReq(r *http.Request, msg proto.Message) error {
	data, err := ioutil.ReadAll(r.Body)
	if err != nil {
		return NewHttpError(err, http.StatusBadRequest)
	}
	r.Body.Close()
	err = proto.Unmarshal(data, msg)
	if err != nil {
		return NewHttpError(err, http.StatusBadRequest)
	}
	return nil
}

func ReadJsonReq(r *http.Request, msg proto.Message) error {
	data, err := ioutil.ReadAll(r.Body)
	if err != nil {
		return NewHttpError(err, http.StatusBadRequest)
	}
	r.Body.Close()
	err = json.Unmarshal(data, msg)
	if err != nil {
		return NewHttpError(err, http.StatusBadRequest)
	}
	return nil
}

func WriteProtoRsp(w http.ResponseWriter, msg proto.Message) error {
	rsp, err := proto.Marshal(msg)
	if err != nil {
		return err
	}
	_, err = w.Write(rsp)
	if err != nil {
		return err
	}
	return nil
}

func WriteJsonRsp(w http.ResponseWriter, msg proto.Message) error {
	rsp, err := json.Marshal(msg)
	if err != nil {
		return err
	}
	_, err = w.Write(rsp)
	if err != nil {
		return err
	}
	return nil
}

func isPrivateIP(ip net.IP) bool {
	return false
}

func GetRemoteIPAddr(r *http.Request) string {
	headers := []string{
		"X-Forwarded-For", "X-Real_Ip",
	}

	for _, header := range headers {
		addrList := strings.Split(r.Header.Get(header), ",")
		for _, addr := range addrList {
			ipString := strings.TrimSpace(addr)
			ip := net.ParseIP(ipString)
			if isPrivateIP(ip) { // ? globalUnicast?
				continue
			}
			return ipString
		}
	}
	addrList := strings.Split(r.RemoteAddr, ":")
	if len(addrList) > 0 {
		ip := net.ParseIP(addrList[0])
		if isPrivateIP(ip) == false {
			return addrList[0]
		}
	}
	return ""
}

func GetAuthorizationHeader(r *http.Request) string {
	auth := r.Header.Get("Authorization")
	if auth == "" {
		return "" // NewHttpError(errors.New("NO_AUTH_DATA"), http.StatusUnauthorized)
	}
	splitted := strings.Split(auth, " ")
	if len(splitted) != 2 || strings.ToLower(splitted[0]) != "bearer" {
		return ""
	}
	return splitted[1]
}
