package sample

import (
	"context"
	"github.com/ring3/goserve/core"
	// "go.uber.org/zap"
	"net/http"
	_ "net/http/pprof"
)

// module
type Sample struct {
	core.BaseComponent
}

// module interfaces
func (s *Sample) Init(n *core.Node, cfg *core.ModuleConfig) {
	(&s.BaseComponent).Init(n, cfg)
}

func (s *Sample) Run(ctx context.Context) error {
	s.Log.Info("Sample start")
	http.ListenAndServe("localhost:6060", nil)
	return nil
}
