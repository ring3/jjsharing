package sample

import (
	"github.com/ring3/goserve/core"
)

// module register
func init() {
	core.RegisterCompType("Sample", (*Sample)(nil))
}
