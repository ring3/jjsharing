package entryservice

import (
	"github.com/ring3/goserve/core"
)

// module register
func init() {
	core.RegisterCompType("Entrance", (*Entrance)(nil))
}
