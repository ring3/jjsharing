package entryservice

import (
	"context"
	"fmt"
	"github.com/ring3/goserve/core"
	"github.com/ring3/goserve/data/proto/generated"
	"github.com/ring3/goserve/service/common"
	"github.com/ring3/goserve/util"
	"go.uber.org/zap"
	"net/http"
)

// module
type Entrance struct {
	core.BaseComponent
	server  *util.HttpServer
	useJson bool
	tknUtil *util.TokenUtil
}

// service interface
func (en *Entrance) ServiceID() int {
	return servicecommon.ServiceID_ENTRY
}

// module interfaces
func (en *Entrance) Init(n *core.Node, cfg *core.ModuleConfig) {
	(&en.BaseComponent).Init(n, cfg)
	en.NewHttpServer()
	en.SetURLs()
	useJson, _ := en.Config.GetBool("jsonRequest")
	en.useJson = useJson
	en.tknUtil = util.NewUserTokenUtil()
}

func (en *Entrance) Run(ctx context.Context) error {
	return en.RunHttpServer(ctx, en.server)
}

func (en *Entrance) Update(ctx context.Context) error {
	return nil
}

func (en *Entrance) NewHttpServer() {
	addr, ok := en.Config.GetString("http_addr")
	if ok == false {
		panic(fmt.Sprintf("NewHttpServer without http_addr, %s.", en.Name()))
	}
	httpConfig := util.HttpServerConfig{Addr: addr}
	en.server = util.NewHttpServer(&httpConfig, en.Log)
}

func (en *Entrance) SetURLs() {
	en.server.Handle("/login", en.login)
	en.server.Handle("/register", en.register)

	// for testing
	en.server.Handle("/testiowrite", en.testIoWriteString)
	en.server.Handle("/testerror500", en.testInternalError)
	en.server.Handle("/testerror404", en.test404HttpError)
	en.server.Handle("/testsecure", en.SecureHandle(en.test404HttpError))
}

// http handlers
func (en *Entrance) login(w http.ResponseWriter, req *http.Request) error {
	ctx := req.Context()
	loginReq := pbdata.LoginReq{
		// Token: "test login token",
	}

	en.ReadHttpReq(req, &loginReq)

	ls, err := en.getLoginServiceClient()
	if err != nil {
		return err
	}
	_, err1 := ls.Login(ctx, &loginReq)
	if err1 != nil {
		return err1
	}

	as, err := en.getAccountServiceClient()
	if err != nil {
		return err
	}

	uidReq := pbdata.AccountIDReq{
		AccountId: 1234,
	}
	rsp, err := as.GetAccountData(ctx, &uidReq)
	if err != nil {
		return errNoAccountData
	}
	en.Log.Info("en.Login() calls GetAccountData() returns", zap.Any("accountInfo", rsp))

	uid := uint64(123456)
	stk, err := en.tknUtil.CreateUserToken(uid)
	if err != nil {
		en.Log.Error("en.Login() create token fail", zap.Error(err))
		return errGenerateToken
	}
	loginRsp := pbdata.LoginRsp{
		UserId:      uid,
		Nickname:    "loginRspName",
		SecureToken: stk,
	}
	return en.WriteHttpRsp(w, &loginRsp)
}

func (en *Entrance) register(w http.ResponseWriter, req *http.Request) error {
	regReq := pbdata.RegisterReq{
		// Token: "test login token",
	}
	en.ReadHttpReq(req, &regReq)
	return en.WriteHttpRsp(w, &pbdata.None{})
}
