package entryservice

import (
	"fmt"
	"github.com/ring3/goserve/util"
	"io"
	"net/http"
)

func (en *Entrance) testIoWriteString(w http.ResponseWriter, req *http.Request) error {
	// io.WriteString(w, fmt.Sprintf("test login, token=%s.", loginReq.Token))
	io.WriteString(w, fmt.Sprintf("testIoWriteString , nick=%s.", "nickabc"))
	return nil
}

func (en *Entrance) testInternalError(w http.ResponseWriter, req *http.Request) error {
	return errNoAccountService
}

func (en *Entrance) test404HttpError(w http.ResponseWriter, req *http.Request) error {
	return util.NewHttpError(errNoAccountData, http.StatusNotFound)
}
