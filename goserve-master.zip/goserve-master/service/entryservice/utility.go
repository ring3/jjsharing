package entryservice

import (
	"errors"
	"github.com/ring3/goserve/service/accountservice"
	"github.com/ring3/goserve/service/common"
	"github.com/ring3/goserve/service/loginservice"
	"github.com/ring3/goserve/util"
	"go.uber.org/zap"
	"google.golang.org/protobuf/proto"
	"net/http"
	"time"
)

func (en *Entrance) SecureHandle(f util.HttpHandleFunc) util.HttpHandleFunc {
	return func(w http.ResponseWriter, r *http.Request) error {
		authHeader := util.GetAuthorizationHeader(r)
		if authHeader == "" {
			return util.NewHttpError(errors.New("NO_AUTH_DATA"), http.StatusUnauthorized)
		}

		claim, err := en.tknUtil.V(authHeader)
		if err != nil {
			return util.NewHttpError(errors.New("AUTH_FAIL"), http.StatusUnauthorized)
		}

		en.Log.Info("en.SecureHandle()", zap.Any("claim", claim))
		return f(w, r)
	}
}

func (en *Entrance) ReadHttpReq(req *http.Request, msg proto.Message) error {
	if en.useJson {
		return util.ReadJsonReq(req, msg)
	} else {
		return util.ReadProtoReq(req, msg)
	}
}

func (en *Entrance) WriteHttpRsp(w http.ResponseWriter, msg proto.Message) error {
	if en.useJson {
		return util.WriteJsonRsp(w, msg)
	} else {
		return util.WriteProtoRsp(w, msg)
	}
}

func (en *Entrance) getAccountServiceClient() (accountservice.IAccountService, error) {
	svc, ok := en.FindService(servicecommon.ServiceID_ACCOUNT)
	if ok == false {
		return nil, errNoAccountService
	}
	as, ok := svc.(accountservice.IAccountService)
	if ok == false {
		return nil, errInvalidAccountService
	}
	return as, nil
}

func (en *Entrance) getLoginServiceClient() (loginservice.ILoginService, error) {
	svc, ok := en.FindService(servicecommon.ServiceID_LOGIN)
	if ok == false {
		return nil, errNoLoginService
	}
	ls, ok := svc.(loginservice.ILoginService)
	if ok == false {
		return nil, errInvalidLoginService
	}
	return ls, nil
}

// func to mock abnormal situation
func (en *Entrance) infiniteLoop(req *http.Request) {
	ip := util.GetRemoteIPAddr(req)
	goid := util.GetGoroutineID()
	for {
		time.Sleep(time.Duration(5) * time.Second)
		en.Log.Info("sleeping on", zap.String("ip", ip), zap.Uint64("goid", goid))
	}
}
