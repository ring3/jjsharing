package entryservice

import (
	"errors"
	"github.com/ring3/goserve/service/common"
)

var (
	errNoAccountService      = errors.New(servicecommon.TXT_ERR_NO_ACCOUNT_SERVICE)
	errNoLoginService        = errors.New(servicecommon.TXT_ERR_NO_LOGIN_SERVICE)
	errInvalidAccountService = errors.New(servicecommon.TXT_ERR_INVALID_ACCOUNT_SERVICE)
	errInvalidLoginService   = errors.New(servicecommon.TXT_ERR_INVALID_LOGIN_SERVICE)
	errNoAccountData         = errors.New(servicecommon.TXT_ERR_NO_ACCOUNT_DATA)
	errGenerateToken         = errors.New("unknown")
)
