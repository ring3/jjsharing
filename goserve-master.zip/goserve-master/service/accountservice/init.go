package accountservice

import (
	"context"
	"github.com/ring3/goserve/core"
	"github.com/ring3/goserve/data/proto/generated"
	// "github.com/ring3/goserve/util"
	// "go.uber.org/zap"
	// "google.golang.org/protobuf/proto"
)

// module register
func init() {
	core.RegisterCompType("AccountService", (*AccountService)(nil))
}

type IAccountService interface {
	Register(ctx context.Context, req *pbdata.RegisterReq) (*pbdata.RegisterRsp, error)
	GetAccountData(ctx context.Context, req *pbdata.AccountIDReq) (*pbdata.AccountInfo, error)
}
