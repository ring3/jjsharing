package accountservice

import (
	"context"
	"github.com/ring3/goserve/core"
	"github.com/ring3/goserve/data/proto/generated"
	"github.com/ring3/goserve/service/common"
	"go.uber.org/zap"
)

// module & service
type AccountService struct {
	core.BaseComponent
}

// module interfaces
func (as *AccountService) Init(n *core.Node, cfg *core.ModuleConfig) {
	(&as.BaseComponent).Init(n, cfg)
}

func (as *AccountService) Run(ctx context.Context) error {
	select {
	case <-ctx.Done():
		as.Log.Info("as.Run() ctx.Done")
	}
	return nil
}

// service interface
func (as *AccountService) ServiceID() int {
	return servicecommon.ServiceID_ACCOUNT
}

func (as *AccountService) Register(ctx context.Context, req *pbdata.RegisterReq) (*pbdata.RegisterRsp, error) {
	as.Log.Info("Register", zap.String("oid", req.OpenId))

	rsp := pbdata.RegisterRsp{
		Result: true,
		Reason: "ok",
		Info: &pbdata.AccountInfo{
			OpenId:    "123456",
			AccountId: 3000000,
			Nickname:  "testname",
		},
	}
	return &rsp, nil
}

func (as *AccountService) GetAccountData(ctx context.Context, req *pbdata.AccountIDReq) (*pbdata.AccountInfo, error) {
	as.Log.Info("GetAccountData", zap.Uint64("uid", req.AccountId))
	info := &pbdata.AccountInfo{
		OpenId:    "123456",
		AccountId: 3000000,
		Nickname:  "testname",
	}
	return info, nil
}
