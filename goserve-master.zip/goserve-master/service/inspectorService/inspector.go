package inspector

import (
	"context"
	_ "errors"
	"fmt"
	"github.com/ring3/goserve/core"
	"github.com/ring3/goserve/service/common"
	"github.com/ring3/goserve/util"
	_ "go.uber.org/zap"
	"io"
	"net/http"
	"net/http/pprof"
)

// module
type Inspector struct {
	core.BaseComponent
	server *util.HttpServer
}

// module interfaces
func (is *Inspector) ID() int {
	return servicecommon.ServiceID_INSPECT
}

func (is *Inspector) Init(n *core.Node, cfg *core.ModuleConfig) {
	(&is.BaseComponent).Init(n, cfg)
	is.NewHttpServer()
}

func (is *Inspector) Run(ctx context.Context) error {
	err := is.RunHttpServer(ctx, is.server)
	return err
}

// impl
func (is *Inspector) NewHttpServer() {
	addr, ok := is.Config.GetString("http_addr")
	if ok == false {
		panic(fmt.Sprintf("NewHttpServer without http_addr, %s.", is.Name()))
	}
	httpConfig := util.HttpServerConfig{Addr: addr}
	is.server = util.NewHttpServer(&httpConfig, is.Log)

	// pprof
	is.server.HandleFunc("/debug/pprof/", pprof.Index)
	is.server.HandleFunc("/debug/pprof/cmdline", pprof.Cmdline)
	is.server.HandleFunc("/debug/pprof/profile", pprof.Profile)
	is.server.HandleFunc("/debug/pprof/symbol", pprof.Symbol)
	is.server.HandleFunc("/debug/pprof/trace", pprof.Trace)

	// console
	is.server.Handle("/console/", is.Console)
}

// http handlers
func (is *Inspector) Console(w http.ResponseWriter, req *http.Request) error {
	io.WriteString(w, "test console")
	return nil
}
