package inspector

import (
	"github.com/ring3/goserve/core"
)

// module register
func init() {
	core.RegisterCompType("Inspector", (*Inspector)(nil))
}
