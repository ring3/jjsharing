package loginservice

import (
	"context"
	"github.com/ring3/goserve/core"
	"github.com/ring3/goserve/data/proto/generated"
	"github.com/ring3/goserve/service/common"
	"go.uber.org/zap"
)

// module and service
type LoginService struct {
	core.BaseComponent
}

// module
func (ls *LoginService) Init(n *core.Node, cfg *core.ModuleConfig) {
	(&ls.BaseComponent).Init(n, cfg)
}

func (ls *LoginService) Run(ctx context.Context) error {
	select {
	case <-ctx.Done():
		ls.Log.Info("ls.Run() ctx.Done")
	}
	return nil
}

// service

func (ls *LoginService) ServiceID() int {
	return servicecommon.ServiceID_LOGIN
}

func (ls *LoginService) Login(ctx context.Context, req *pbdata.LoginReq) (*pbdata.LoginRsp, error) {
	ls.Log.Info("Login", zap.String("oid", req.OpenId))
	return nil, nil
}

func (ls *LoginService) Logout(ctx context.Context, req *pbdata.AccountIDReq) (*pbdata.LogoutRsp, error) {
	ls.Log.Info("Logout", zap.Uint64("uid", req.AccountId))
	return nil, nil
}
