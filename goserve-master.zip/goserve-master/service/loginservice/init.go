package loginservice

import (
	"context"
	"github.com/ring3/goserve/core"
	"github.com/ring3/goserve/data/proto/generated"
)

// module register
func init() {
	core.RegisterCompType("LoginService", (*LoginService)(nil))
}

type ILoginService interface {
	Login(ctx context.Context, req *pbdata.LoginReq) (*pbdata.LoginRsp, error)
	Logout(ctx context.Context, req *pbdata.AccountIDReq) (*pbdata.LogoutRsp, error)
}
