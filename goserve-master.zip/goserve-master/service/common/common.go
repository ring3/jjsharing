package servicecommon

const (
	ServiceID_NONE        = 0
	ServiceID_INSPECT     = 8
	ServiceID_ENTRY       = 10
	ServiceID_LOGIN       = 100
	ServiceID_ACCOUNT     = 101
	ServiceID_LEADERBOARD = 102
)

func GetServiceName(sid int) string {
	switch sid {
	case ServiceID_NONE:
		return "None"
	case ServiceID_INSPECT:
		return "Inspector"
	case ServiceID_ENTRY:
		return "Entrance"
	case ServiceID_LOGIN:
		return "Login"
	case ServiceID_ACCOUNT:
		return "Account"
	case ServiceID_LEADERBOARD:
		return "Leaderboard"
	default:
		return "UnknownService"
	}
}
