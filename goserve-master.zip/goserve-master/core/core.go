package core

import (
	"context"
	"errors"
	"fmt"
	"github.com/natefinch/lumberjack"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
	"os"
	"reflect"

	"sync"
)

var (
	componentTypes = make(map[string]reflect.Type)
)

func RegisterCompType(name string, c IComponent) {
	t := reflect.TypeOf(c)
	componentTypes[name] = t
}

func ComponentType(name string) (reflect.Type, bool) {
	val, ok := componentTypes[name]
	return val, ok
}

func CheckComponent() bool {
	return len(componentTypes) > 0
}

type BaseComponent struct {
	Config *ModuleConfig
	Log    *zap.Logger
	node   *Node
}

func (bc *BaseComponent) Name() string {
	name, ok := bc.Config.GetString("Name")
	if ok == false {
		return reflect.TypeOf(bc).String()
	}
	return name
}

func (bc *BaseComponent) Init(n *Node, cfg *ModuleConfig) {
	bc.Config = cfg
	bc.Log = n.GetLogger()
	bc.node = n
}

func (bc *BaseComponent) Update(ctx context.Context) error {
	return nil
}

func (bc *BaseComponent) FindService(serviceID int) (IService, bool) {
	if bc.node.services == nil {
		return nil, false
	}
	svc, ok := bc.node.services[serviceID]
	return svc, ok
}

func (bc *BaseComponent) Blocking(ctx context.Context) {
	// for
	{
		select {
		case <-ctx.Done():
			// bc.Log.Info("Blocking done!", zap.String("Module", bc.Name()))
			return
		}
	}
}

func (bc *BaseComponent) RunHttpServer(ctx context.Context, server IHttpServer) error {
	ch := make(chan error, 2)
	var wg sync.WaitGroup

	defer func() {
		wg.Wait()
		close(ch)
	}()

	go func(ch chan error) {
		wg.Add(1)
		defer wg.Done()
		err := server.Run()

		// notify outside that the http server encountered error
		if err != nil {
			select {
			case ch <- err:
			default:
			}
		}
	}(ch)

	select {
	case err := <-ch:
		// bc.Log.Info("bc notify err")
		server.Shutdown()
		return err
	case <-ctx.Done():
		// bc.Log.Info("bc done")
		server.Shutdown()
		return nil
	}
}

func (bc *BaseComponent) SendData() {

}

func initLogger(config *LogConfig) (*zap.Logger, error) {
	if config == nil {
		return nil, errors.New("nil log config")
	}
	// level
	var level zapcore.Level
	if config.Level == "debug" {
		level = zap.DebugLevel
	} else if config.Level == "info" {
		level = zap.InfoLevel
	} else if config.Level == "warn" {
		level = zap.WarnLevel
	} else if config.Level == "error" {
		level = zap.ErrorLevel
	} else {
		level = zap.InfoLevel
	}

	// file syncer
	lumberjack := &lumberjack.Logger{
		Filename:   fmt.Sprintf("%s", config.Filename),
		MaxSize:    100, // mb,
		MaxBackups: 10,
		MaxAge:     30,
		Compress:   false,
	}
	writer := zapcore.AddSync(lumberjack)

	// opt, encoder and core
	var opts []zap.Option
	var encoder zapcore.Encoder
	var core zapcore.Core
	if config.Env == "dev" {
		opts = []zap.Option{
			zap.Development(),
			zap.AddCaller(),
			zap.AddStacktrace(zap.WarnLevel),
		}
		encoderConfig := zap.NewDevelopmentEncoderConfig()
		encoder = zapcore.NewConsoleEncoder(encoderConfig)
	} else if config.Env == "prod" {
		opts = []zap.Option{
			zap.AddCaller(),
			zap.AddStacktrace(zap.WarnLevel),
		}
		encoderConfig := zap.NewProductionEncoderConfig()
		encoder = zapcore.NewJSONEncoder(encoderConfig)
	}
	if config.Stdout == true {
		writer = zap.CombineWriteSyncers(writer, os.Stderr)
	}
	core = zapcore.NewCore(encoder, writer, level)
	logger := zap.New(core, opts...)

	// TODO: daily log file split
	return logger, nil

}

func endLogger(logger *zap.Logger) {
	if logger != nil {
		logger.Sync()
	}
}
