package core

import (
	"encoding/json"
	"fmt"
)

type NodeConfig struct {
	NodeId  int
	Name    string
	Log     *LogConfig
	FrameMS int
}

type ModuleConfig struct {
	m map[string]interface{}
}

func NewModuleConfig(kv map[string]interface{}) *ModuleConfig {
	cc := ModuleConfig{
		m: kv,
	}
	return &cc
}

func (mc *ModuleConfig) Print() {
	for k, v := range mc.m {
		fmt.Println(k, v)
	}
}

func (mc *ModuleConfig) Get(k string) (interface{}, bool) {
	v, ok := mc.m[k]
	return v, ok
}

func (mc *ModuleConfig) GetString(k string) (string, bool) {
	v, ok := mc.Get(k)
	if ok == false {
		return "", false
	}
	return v.(string), true
}

func (mc *ModuleConfig) GetBool(k string) (bool, bool) {
	v, ok := mc.Get(k)
	if ok == false {
		return false, false
	}
	return v.(bool), true
}

func (mc *ModuleConfig) GetByte(k string) (byte, bool) {
	v, ok := mc.Get(k)
	if ok == false {
		return 0, false
	}

	switch vt := v.(type) {
	case string:
		fmt.Println("v is string", vt)
		return 0, false
	case int:
		return byte(vt), true
	case int64:
		return byte(vt), true
	case float64:
		return byte(vt), true
	case json.Number:
		i64, err := vt.Int64()
		if err != nil {
			fmt.Println("i643")
			return 0, false
		}
		return byte(i64), true
	default:
		fmt.Println("no idea")
		return 0, false
	}
}

func (mc *ModuleConfig) GetInt(k string) (int, bool) {
	v, ok := mc.Get(k)
	if ok == false {
		return 0, false
	}

	switch vt := v.(type) {
	case string:
		fmt.Println("v is string", vt)
		return 0, false
	case int:
		return vt, true
	case int64:
		return int(vt), true
	case float64:
		return int(vt), true
	case json.Number:
		i64, err := vt.Int64()
		if err != nil {
			fmt.Println("i643")
			return 0, false
		}
		return int(i64), true
	default:
		fmt.Println("no idea")
		return 0, false
	}
}

func (mc *ModuleConfig) GetInt64(k string) (int64, bool) {
	v, ok := mc.Get(k)
	if ok == false {
		return 0, false
	}

	switch vt := v.(type) {
	case string:
		fmt.Println("v is string", vt)
		return 0, false
	case int:
		return int64(vt), true
	case int64:
		return vt, true
	case float64:
		return int64(vt), true
	case json.Number:
		i64, err := vt.Int64()
		if err != nil {
			fmt.Println("i643")
			return 0, false
		}
		return i64, true
	default:
		fmt.Println("no idea")
		return 0, false
	}
}

func (mc *ModuleConfig) GetUint(k string) (uint, bool) {
	v, ok := mc.Get(k)
	if ok == false {
		return 0, false
	}

	switch vt := v.(type) {
	case string:
		fmt.Println("v is string", vt)
		return 0, false
	case int:
		return uint(vt), true
	case int64:
		return uint(vt), true
	case float64:
		return uint(vt), true
	case json.Number:
		i64, err := vt.Int64()
		if err != nil {
			fmt.Println("i643")
			return 0, false
		}
		return uint(i64), true
	default:
		fmt.Println("no idea")
		return 0, false
	}
}

func (mc *ModuleConfig) GetFloat32(k string) (float32, bool) {
	v, ok := mc.Get(k)
	if ok == false {
		return 0, false
	}

	switch vt := v.(type) {
	case string:
		fmt.Println("v is string", vt)
		return 0, false
	case int:
		return float32(vt), true
	case int64:
		return float32(vt), true
	case float64:
		return float32(vt), true
	case json.Number:
		f64, err := vt.Float64()
		if err != nil {
			fmt.Println("i643")
			return 0, false
		}
		return float32(f64), true
	default:
		fmt.Println("no idea")
		return 0, false
	}
}

func (mc *ModuleConfig) GetFloat64(k string) (float64, bool) {
	v, ok := mc.Get(k)
	if ok == false {
		return 0, false
	}

	switch vt := v.(type) {
	case string:
		fmt.Println("v is string", vt)
		return 0, false
	case int:
		return float64(vt), true
	case int64:
		return float64(vt), true
	case float64:
		return float64(vt), true
	case json.Number:
		f64, err := vt.Float64()
		if err != nil {
			fmt.Println("i643")
			return 0, false
		}
		return f64, true
	default:
		fmt.Println("no idea")
		return 0, false
	}

}

type LogConfig struct {
	Env      string // dev, prod,
	Filename string
	Level    string // debug, info, warn, error
	Stdout   bool
}
