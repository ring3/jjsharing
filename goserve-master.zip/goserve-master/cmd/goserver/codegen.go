package main

// import (
// 	_ "github.com/ring3/goserve/service/gatewayService"
// 	_ "github.com/ring3/goserve/service/inspectorService"
// 	_ "github.com/ring3/goserve/service/sampleService"
// )
