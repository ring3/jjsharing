package storage

import (
	// _ "github.com/gomodule/redigo/redis"
	"github.com/golang/protobuf/proto"
	radix "github.com/mediocregopher/radix/v3"
)

// radix, redigo
// https://godoc.org/github.com/mediocregopher/radix
// https://www.alexedwards.net/blog/working-with-redis

type RedisCli struct {
	Url    string
	Size   int
	client *radix.Pool
}

func NewRedisCli(url string, sz int) (*RedisCli, error) {
	pool, err := radix.NewPool("tcp", url, sz)
	if err != nil {
		return nil, err
	}
	rc := RedisCli{
		Url:    url,
		Size:   sz,
		client: pool,
	}
	return &rc, nil
}

func (rc *RedisCli) Close() error {
	return rc.client.Close()
}

// err := rc.SetStr("k", "123"), TOOD: SetInt, SetUint64, Set...
func (rc *RedisCli) SetStr(key string, value string) error {
	if err := rc.client.Do(radix.Cmd(nil, "SET", key, value)); err != nil {
		return err
	}
	return nil
}

// err := rc.Set("k", 123)
func (rc *RedisCli) Set(key string, value interface{}) error {
	if err := rc.client.Do(radix.FlatCmd(nil, "SET", key, value)); err != nil {
		return err
	}
	return nil
}

// err := rc.SetEx("k", 123)
func (rc *RedisCli) SetEx(key string, value interface{}, timeoutSec int) error {
	if err := rc.client.Do(radix.FlatCmd(nil, "SET", key, value, "EX", timeoutSec)); err != nil {
		return err
	}
	return nil
}

// SET key value EX sec PX millisec NX|XX
// Nx: set if key not exists
func (rc *RedisCli) SetNx(key string, value interface{}, timeoutSec int) error {
	if err := rc.client.Do(radix.FlatCmd(nil, "SET", key, value, "EX", timeoutSec)); err != nil {
		return err
	}
	return nil
}

// Xx: set if key exists
func (rc *RedisCli) SetXx(key string, value interface{}, timeoutSec int) error {
	if err := rc.client.Do(radix.FlatCmd(nil, "SET", key, value, "EX", timeoutSec, "XX")); err != nil {
		return err
	}
	return nil
}

// value needs to be passed as a pointer if it is a primitive, slice/map.
// var v string/int/...
// err := rc.Get("key", &v)
func (rc *RedisCli) Get(key string, value interface{}) error {
	if err := rc.client.Do(radix.FlatCmd(value, "GET", key)); err != nil {
		return err
	}
	return nil
}

// getset newValue, returns oldValue
func (rc *RedisCli) GetSet(key string, newValue string, oldValue *string) error {
	if err := rc.client.Do(radix.Cmd(oldValue, "GET", key, newValue)); err != nil {
		return err
	}
	return nil
}

func (rc *RedisCli) Del(key string) error {
	if err := rc.client.Do(radix.Cmd(nil, "DEL", key)); err != nil {
		return err
	}
	return nil
}

// delete multiple keys
func (rc *RedisCli) MDel(keys ...string) error {
	if err := rc.client.Do(radix.Cmd(nil, "DEL", keys...)); err != nil {
		return err
	}
	return nil
}

func (rc *RedisCli) Expire(key string, timeoutSec int) error {
	if err := rc.client.Do(radix.FlatCmd(nil, "EXPIRE", key, timeoutSec)); err != nil {
		return err
	}
	return nil
}

// TODO(for leaderboard): zadd, zcount, ZRangeWithScores, ZRevRangeWithScores, ZRemRangeByRank, ZRem, ZRank, ZRevRank, ZScore
// TODO: lpush, lpop, llen, lindex, linsert, lrange, lrem, lset, etc

// some general util functions, simple wrap radix
type Action = radix.Action

func (rc *RedisCli) Do(action Action) error {
	return rc.client.Do(action)
}

type CmdAction = radix.CmdAction

var (
	Cmd     = radix.Cmd
	CmdFlat = radix.FlatCmd
)

func (rc *RedisCli) Pipeline(actions []CmdAction) error {
	p := radix.Pipeline(
		actions...,
	)
	if err := rc.client.Do(p); err != nil {
		return err
	}
	return nil
}

// protobuf utils
func ProtoUnmarshal(data []byte, msg proto.Message) error {
	if err := proto.Unmarshal(data, msg); err != nil {
		return err
	}
	return nil
}

func (rc *RedisCli) GetProto(key string, value proto.Message) error {
	var serialized []byte
	if err := rc.client.Do(radix.Cmd(&serialized, "GET", key)); err != nil {
		return err
	}
	return proto.Unmarshal(serialized, value)
}

func (rc *RedisCli) SetProto(key string, value proto.Message, timeoutSec int) error {
	serialized, err := proto.Marshal(value)
	if err != nil {
		return err
	}
	if err := rc.client.Do(radix.FlatCmd(nil, "SET", key, serialized, "EX", timeoutSec)); err != nil {
		return err
	}
	return nil
}
