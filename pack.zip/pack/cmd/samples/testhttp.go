package main

import (
	"fmt"
	//"io"
	"io/ioutil"
	"net/http"
	"strings"
)

func Post(url string, headers map[string]string, body string) (string, error) {
	req, err := http.NewRequest("POST", url, strings.NewReader(body))
	if err != nil {
		fmt.Println("fatal create request err, %v", err)
		return "", err
	}

	if headers != nil {
		for k, v := range headers {
			req.Header.Set(k, v)
		}
	}

	c := http.Client{}
	rsp, err := c.Do(req)
	if err != nil {
		fmt.Println("fatal post err, %v", err)
		return "", err
	}

	data, err := ioutil.ReadAll(rsp.Body)
	rsp.Body.Close()
	if err != nil {
		fmt.Println("fatal post err, %v", err)
		return "", err
	}
	fmt.Printf("%s", data)
	return "ok", nil
}
