package main

import (
	"database/sql"
	"fmt"
	"github.com/jmoiron/sqlx"
	_ "github.com/mattn/go-sqlite3"
)

const (
	sqlitedbname = "./data/sample.db"
)

// to use go-sqlite3 need to have gcc installed
// http://tdm-gcc.tdragon.net/download
func testbuiltin() {
	db, err := sql.Open("sqlite3", sqlitedbname)
	if err != nil {
		fmt.Println("open db fail, %s", err.Error())
		return
	}
	db.Ping()

	createStmt, err := db.Prepare(
		"CREATE TABLE IF NOT EXISTS address(id INTEGER PRIMARY KEY, firstname VARCHAR, lastname VARCHAR, addr VARCHAR)")
	if err != nil {
		fmt.Println("create table fail, %s", err.Error())
		return
	}
	createStmt.Exec()

	insertStmt, err := db.Prepare("INSERT INTO address(firstname, lastname, addr) VALUES (?, ?, ?)")
	if err != nil {
		fmt.Println("insert table fail, %s", err.Error())
		return
	}
	insertStmt.Exec("fff", "LLL", "My address")

	data, err := db.Query("SELECT id, firstname, lastname, addr FROM address")
	if err != nil {
		fmt.Println("query table fail, %s", err.Error())
		return
	}

	var id int
	var f string
	var l string
	var a string

	defer data.Close() // ensure rows closed
	for data.Next() {
		data.Scan(&id, &f, &l, &a)
		fmt.Printf("id=%d, firstname=%s, lastname=%s, address=%s\n", id, f, l, a)
	}

	// It is rare to Close a DB, as the DB handle is meant to be long-lived and shared between many goroutines.
	db.Close()
}

type Address struct {
	Id        int
	Firstname string
	Lastname  string
	Address   string `db:"addr"`
}

// http://jmoiron.github.io/sqlx/
// https://zhuanlan.zhihu.com/p/157480094
func testsqlx() {
	db, err := sqlx.Open("sqlite3", sqlitedbname)
	if err != nil {
		fmt.Println("sqlx open db fail, %s", err.Error())
		return
	}
	db.Ping()

	data, err := db.Queryx("SELECT id, firstname, lastname, addr FROM address")
	defer data.Close() // ensure rows closed
	for data.Next() {
		var a Address
		err = data.StructScan(&a)
		fmt.Println("a value is ", a)
	}

	// It is rare to Close a DB, as the DB handle is meant to be long-lived and shared between many goroutines.
	db.Close()
}
