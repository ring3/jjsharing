package main

import (
	"fmt"
)

// radix
// https://godoc.org/github.com/mediocregopher/radix

// redigo
// https://www.alexedwards.net/blog/working-with-redis

import (
	"github.com/ring3/goserve/util/storage"
)

func TestRedisCli() {
	rc, err := storage.NewRedisCli("127.0.0.1:6379", 10)
	if err != nil {
		fmt.Println(fmt.Errorf("create redis client fail, %v", err))
	}
	rc.Set("foo", 123)
	var v int
	rc.Get("foo", &v)
}
