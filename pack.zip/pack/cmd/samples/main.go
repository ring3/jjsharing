package main

import (
	"fmt"
	"os"
)

func main() {
	fmt.Println("main()", os.Args)
	var url string
	var token string
	if len(os.Args) == 1 {
		fmt.Println("test sql")
		testbuiltin()
		testsqlx()
		return
	}

	fmt.Println("test http")
	if len(os.Args) > 1 {
		url = os.Args[1]
	}
	if len(os.Args) > 2 {
		token = os.Args[2]
	}

	h := make(map[string]string)
	if token != "" {
		h["Authorization"] = fmt.Sprintf("Bearer %s", token)
	}
	// Authorization: Bearer {tokenvalue}
	Post(url, h, "test body")
}
